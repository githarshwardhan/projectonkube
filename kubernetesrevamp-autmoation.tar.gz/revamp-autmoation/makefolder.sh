#!/bin/bash 
echo "Create the admin upload folder in /mnt Direcotry"
mkdir -p /mnt/adminupload/admin/users/profile
mkdir -p /mnt/adminupload/admin/inductiontraining/inductioncategorydocs
mkdir -p /mnt/adminupload/admin/toolboxtraining/documents
mkdir -p /mnt/adminupload/admin/contractorfirm/images
mkdir -p /mnt/adminupload/admin/contractorfirm/workorderphotos
mkdir -p /mnt/adminupload/admin/workpermit/documents

echo "#################################################################"
